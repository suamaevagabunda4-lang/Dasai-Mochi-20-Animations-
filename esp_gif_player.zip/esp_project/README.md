# ESP8266 + SSD1306 GIF Player

## Como compilar e gravar (sem IDE)

### Opção 1: Gitpod (mais fácil)
1. Suba este projeto no GitHub
2. Acesse: `https://gitpod.io/#https://github.com/SEU_USER/SEU_REPO`
3. Espere compilar automaticamente (~2-3 min)
4. Baixe o arquivo `.pio/build/esp8266/firmware.bin`
5. Grave com [ESP Web Flasher](https://esp.huhn.me) ou [ESPTool Web](https://espressif.github.io/esptool-js/)

### Opção 2: PlatformIO local
```bash
pip install platformio
pio run
# Firmware em: .pio/build/esp8266/firmware.bin
```

## Hardware
- ESP8266 (ESP-12E / NodeMCU / Wemos D1 Mini)
- SSD1306 128x64 I2C
  - SDA → D2 (GPIO4)
  - SCL → D1 (GPIO5)
  - VCC → 3.3V
  - GND → GND

## Animações incluídas (17 GIFs, aleatorias sem repetir)
UwU, nheo_mat, police, smirk, speed, squint, star,
sung_nuoc, sung_nuoc_2, sushi, thong_long, turbo,
up_size_down, wheels, xi_khoi, xi_lua, yakura
