#pragma once
#include <Arduino.h>
#include <Adafruit_SSD1306.h>
#include "animations_data.h"

#define FRAME_SIZE 1024  // 128*64/8

class AnimPlayer {
public:
  AnimPlayer(Adafruit_SSD1306 &display) : _display(display) {}

  uint8_t count() { return ANIM_COUNT; }

  const char* getName(uint8_t idx) {
    if (idx >= ANIM_COUNT) return "";
    return (const char*)pgm_read_ptr(&ANIMATIONS[idx].name);
  }

  void startAnim(uint8_t idx, uint8_t loops = 0) {
    if (idx >= ANIM_COUNT) return;
    _curAnim   = idx;
    _curFrame  = 0;
    _loops     = loops;
    _loopsDone = 0;
    _lastFrame = millis();
    _playing   = true;
    _data      = (const uint8_t*)pgm_read_ptr(&ANIMATIONS[idx].data);
    _frameCount= pgm_read_word(&ANIMATIONS[idx].frameCount);
    _delayMs   = pgm_read_word(&ANIMATIONS[idx].delayMs);
    _showFrame(0);
  }

  void update() {
    if (!_playing) return;
    if (millis() - _lastFrame >= _delayMs) {
      _lastFrame = millis();
      _curFrame++;
      if (_curFrame >= _frameCount) {
        _curFrame = 0;
        _loopsDone++;
        if (_loops > 0 && _loopsDone >= _loops) {
          _playing = false;
          return;
        }
      }
      _showFrame(_curFrame);
    }
  }

  bool isPlaying() { return _playing; }

private:
  Adafruit_SSD1306 &_display;
  bool        _playing    = false;
  uint8_t     _curAnim    = 0;
  uint16_t    _curFrame   = 0;
  uint8_t     _loops      = 0;
  uint8_t     _loopsDone  = 0;
  uint32_t    _lastFrame  = 0;
  const uint8_t* _data    = nullptr;
  uint16_t    _frameCount = 0;
  uint16_t    _delayMs    = 100;

  void _showFrame(uint16_t f) {
    uint8_t buf[FRAME_SIZE];
    memcpy_P(buf, _data + (uint32_t)f * FRAME_SIZE, FRAME_SIZE);
    _display.clearDisplay();
    memcpy(_display.getBuffer(), buf, FRAME_SIZE);
    _display.display();
  }
};
