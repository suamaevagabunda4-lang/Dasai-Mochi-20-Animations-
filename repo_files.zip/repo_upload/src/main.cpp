#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "anim_player.h"

#define OLED_ADDR  0x3C
#define OLED_RESET -1

Adafruit_SSD1306 display(128, 64, &Wire, OLED_RESET);
AnimPlayer player(display);

uint8_t shuffleQueue[ANIM_COUNT];
uint8_t queuePos = 0;

void doShuffle() {
  for (uint8_t i = 0; i < ANIM_COUNT; i++) shuffleQueue[i] = i;
  for (uint8_t i = ANIM_COUNT - 1; i > 0; i--) {
    uint8_t j = random(0, i + 1);
    uint8_t tmp = shuffleQueue[i];
    shuffleQueue[i] = shuffleQueue[j];
    shuffleQueue[j] = tmp;
  }
  queuePos = 0;
}

void playNext() {
  if (queuePos >= ANIM_COUNT) doShuffle();
  uint8_t idx = shuffleQueue[queuePos++];
  Serial.printf("[Play] %s\n", player.getName(idx));
  player.startAnim(idx, 1);
}

void setup() {
  Serial.begin(115200);
  randomSeed(analogRead(A0));

  Wire.begin();
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 not found!");
    while (true) delay(1000);
  }
  display.clearDisplay();
  display.display();

  doShuffle();
  playNext();
}

void loop() {
  player.update();
  if (!player.isPlaying()) playNext();
}
